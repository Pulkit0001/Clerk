package com.example.clerk.UIfragments.Groups;

import androidx.lifecycle.ViewModel;

public class GroupViewModel extends ViewModel {
}
