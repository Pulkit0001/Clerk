package com.example.clerk.database;

import androidx.room.Dao;

@Dao
public interface PaymentRecordDAO {
}
