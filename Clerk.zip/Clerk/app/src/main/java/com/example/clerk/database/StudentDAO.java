package com.example.clerk.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface StudentDAO {

    // This method is used for inserting a single student in the studentTable of Database
    // parameter here is the instance of studentTable entity containing all the provided information
    // about the new Student
    @Insert
    void insertStudentDetails(studentTable student);

    //This method is used for deleting a student entry in the student table of the database by the
    // provided ID of that student in the arguments of the function
    @Query("DELETE FROM studentTable WHERE studentID = :id")
    boolean deleteStudent(int id);

    //This method is used for deleting multiple student entries fom the student table of the database
    // by th provided array of IDs in the arguments of the function that are to be deleted
    @Query("DELETE FROM studentTable WHERE studentID IN(:id)")
    boolean deleteStudents(int[] id);

    // the method is provided for updating thr information of a student
    @Update
    boolean updateStudentInfo(studentTable student);

    // Fetch the details about a single student whose ID is provided by the argument of this method
    @Query("SELECT * FROM studentTable WHERE studentID = :id ")
    LiveData<studentTable> getStudentData(int id);

    //This method is used to get details about all the students that are having provide first name
    // and last name in the arguments
    @Query("SELECT * FROM studentTable WHERE `First Name` = :firstName AND `Last Name` = :lastNamae ")
    LiveData<studentTable> getStudentData(String firstName, String lastNamae);

    //This method is used to get the list of all student's name and there IDs(in the form of strings
    // not integer from the defined table. The List is to be used primarily in AutoCompleteTextView
    // to find a student.
    @Query("SELECT CONCAT(`First Name`,`Last Name`) FROM studentTable UNION " +
            "SELECT studentID FROM studentTable")
    LiveData<List<String>> getNameOfStudents();





}


