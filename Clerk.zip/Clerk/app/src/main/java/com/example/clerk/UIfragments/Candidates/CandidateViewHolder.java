package com.example.clerk.UIfragments.Candidates;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CandidateViewHolder extends RecyclerView.ViewHolder {
    public CandidateViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
