package com.example.clerk.UIfragments.Candidates;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.clerk.database.AccountsRepository;
import com.example.clerk.database.studentTable;

import java.util.List;

public class CandidateViewModel extends ViewModel {

    LiveData<List<studentTable>> mCandidates;

    public CandidateViewModel(int id){
        mCandidates= AccountsRepository.getCandidateOfGroup(id);
    }


    public int createCandidate(){

    }

    public void removeCandidate(){

    }

    public void changePic(int id){

    }

    public void editCandidate(int id){

    }

    public void moveTo(int groupId){

    }
}
