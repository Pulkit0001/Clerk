package com.example.clerk.UIfragments.Groups;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GroupViewHolder extends RecyclerView.ViewHolder {
    public GroupViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
