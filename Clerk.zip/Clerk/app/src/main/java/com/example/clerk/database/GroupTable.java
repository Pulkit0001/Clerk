package com.example.clerk.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class GroupTable {

    @ColumnInfo(name="Group ID")
    @PrimaryKey(autoGenerate = true)
    private int group_id;

    @ColumnInfo(name="Name")
    private String group_name;

    @ColumnInfo(name="Strength")
    private int strength;

    public int getGroup_id() {
        return group_id;
    }

    public int getStrength() {
        return strength;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_id(int group_id) {
        this.group_id = group_id;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }
}
