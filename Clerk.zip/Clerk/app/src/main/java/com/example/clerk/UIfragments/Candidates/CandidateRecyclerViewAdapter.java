package com.example.clerk.UIfragments.Candidates;

import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CandidateRecyclerViewAdapter extends RecyclerView.Adapter<CandidateViewHolder>{

    @NonNull
    @Override
    public CandidateViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull CandidateViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
