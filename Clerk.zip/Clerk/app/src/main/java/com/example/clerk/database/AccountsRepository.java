package com.example.clerk.database;

import android.app.Application;
import android.app.ListActivity;

import androidx.lifecycle.LiveData;

import java.util.List;

public class AccountsRepository  {

    StudentDAO studentDAO;
    GroupDAO groupDAO;
    PaymentRecordDAO paymentRecordDAO;

    AccountsRepository(Application application){
        AccountsDatabase database = AccountsDatabase.getDatabase(application);
        studentDAO=database.studentDAO();
        groupDAO=database.groupDAO();
        paymentRecordDAO=database.paymentRecordDAO();

    }

    public static LiveData<List<studentTable>> getCandidateOfGroup(int id){

    }
}
