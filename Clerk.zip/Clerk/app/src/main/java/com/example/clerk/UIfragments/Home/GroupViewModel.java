package com.example.clerk.UIfragments.Home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.clerk.database.GroupTable;

import java.util.List;

public class GroupViewModel extends ViewModel {

    LiveData<GroupTable> mGroups;

    public boolean createNew(){
        //ToDo

        return true;
    }

    public void editGroup(int id){

        //To do
    }

    public void deleteGroup(List<Integer>){
        //Todo Delete a list o groups having ids provided by the list of integers
    }

    public void mergeGroups(List<Integer>){
        //Todo Merge all the groups mentioned in list of integer ids in to one as single group
    }

    public void splitGroup(int id) {
        // to be added in later version
    }
}
