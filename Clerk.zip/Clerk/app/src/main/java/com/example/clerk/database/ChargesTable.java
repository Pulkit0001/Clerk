package com.example.clerk.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class ChargesTable {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "Charge ID")
    int chargeID;

    @ColumnInfo(name = "Charge Name")
    String chargeName;

    @ColumnInfo(name = "Amount")
    int chargeAmount;

    boolean countFromJoinDate; // the boolean is used to represent that whether you want to count from
    // joining date or not.

    @ColumnInfo(name = "Defined Type")
    String paymentTypeDefined;  // Its value will be either Custom or chose from Default Ones which are
    // In Every Week
    //In Every 15 Days
    //In Every Month etc.
}
