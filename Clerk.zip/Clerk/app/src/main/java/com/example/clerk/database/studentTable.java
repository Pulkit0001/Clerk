package com.example.clerk.database;

import androidx.room.ColumnInfo;
import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(foreignKeys = @ForeignKey(entity = GroupTable.class,
        parentColumns = {"Group ID"},
        childColumns = {"Group_ID"},
        onDelete = ForeignKey.CASCADE))
public class studentTable {

    @PrimaryKey(autoGenerate = true)
    public int studentID;

    @ColumnInfo(name = "First Name")
    private String firstName;

    @ColumnInfo(name = "Last Name")
    private String lastName;

    @ColumnInfo(name = "Guardian's Name")
    private String guardianName;

    @ColumnInfo(name = "Age")
    private int age;

    @ColumnInfo(name = "Gender")
    private String gender;

    @ColumnInfo(name = "Joining Date")
    private String joiningDate;

    @ColumnInfo(name = "Leaving Date")
    private String leavingDate;

    //@ColumnInfo(name = "Payment Records")
    //private PaymentRecord MyRecord;

    @ColumnInfo(name="Group_ID")
    private int group_id;

    @Embedded
    private  StudentContactInfo contactInfo;

    public void setAge(int age) {
        this.age = age;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setGuardianName(String guardianName) {
        this.guardianName = guardianName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setGroup_id(int group_id) {
        this.group_id = group_id;
    }

    public void setContactInfo(StudentContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    public void setLeavingDate(String leavingDate) {
        this.leavingDate = leavingDate;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

//    public void setMyRecord(PaymentRecord myRecord) {
//        MyRecord = myRecord;
//    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public String getLeavingDate() {
        return leavingDate;
    }

    public int getAge() {
        return age;
    }

    public int getGroup_id() {
        return group_id;
    }

    public int getStudentID() {
        return studentID;
    }

//    public PaymentRecord getMyRecord() {
//        return MyRecord;
//    }

    public String getFirstName() {
        return firstName;
    }

    public String getGender() {
        return gender;
    }

    public String getGuardianName() {
        return guardianName;
    }

    public String getLastName() {
        return lastName;
    }

    public StudentContactInfo getContactInfo() {
        return contactInfo;
    }
}


