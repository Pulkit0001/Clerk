package com.example.clerk.database;

import androidx.room.Embedded;
import androidx.room.Relation;

import java.util.List;

public class StudentsOfGroup {

    @Embedded
    public GroupTable group;
    @Relation(parentColumn = "group_id",  entityColumn = "id")
    public List<studentTable> students;
}
