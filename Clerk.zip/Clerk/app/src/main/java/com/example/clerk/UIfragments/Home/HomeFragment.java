package com.example.clerk.UIfragments.Home;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.customview.widget.Openable;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.clerk.R;
import com.google.android.material.appbar.CollapsingToolbarLayout;

public class HomeFragment extends Fragment {

    public HomeFragment(){
        //nothing to do here
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_home, container, false);
        CollapsingToolbarLayout layout = v.findViewById(R.id.layout_toolbar);
        DrawerLayout drawerLayout = v.findViewById(R.id.drawer);
        Toolbar toolbar= v.findViewById(R.id.my_toolbar);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.homeFragment,
                R.id.groupsFragment, R.id.candidatesFragment, R.id.discountFragment, R.id.penaltiesFragment,
                R.id.removedFragment, R.id.helpFragment).setDrawerLayout(drawerLayout).build();
        NavController navController = Navigation.findNavController(requireActivity(),R.id.fragment);
        NavigationUI.setupWithNavController(layout,toolbar,navController,appBarConfiguration);
        NavigationUI.setupActionBarWithNavController((AppCompatActivity)requireActivity(),navController, (Openable) toolbar);
        return v;
    }
}