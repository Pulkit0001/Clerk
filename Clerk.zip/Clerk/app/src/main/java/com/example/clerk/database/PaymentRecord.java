package com.example.clerk.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.sql.Time;
import java.util.Date;
import java.util.HashMap;

@Entity(foreignKeys = @ForeignKey(entity = studentTable.class,
                                parentColumns = {"id"},
                                childColumns = {"studentID"},
                                onDelete = ForeignKey.CASCADE))
public class PaymentRecord {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "Payment ID")
    String paymentID;

    @ColumnInfo(name = "Student")
    int studentID;

    @ColumnInfo(name = "Issue Date")
    Date issueDate;

    @ColumnInfo(name = "Due Date")
    Date dueDate;

    @ColumnInfo(name = "Paid date")
    Date paidDate;

    @ColumnInfo(name = "Paid Time")
    Time paidTime;

    @ColumnInfo(name = "Status")
    String status;

    @ColumnInfo(name = "Payment By")
    String method;

    @ColumnInfo(name = "Amount")
    int amount;

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public void setPaidDate(Date paidDate) {
        this.paidDate = paidDate;
    }

    public void setPaidTime(Time paidTime) {
        this.paidTime = paidTime;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public void setPaidAmount(int paidAmount) {
        this.paidAmount = paidAmount;
    }

    public void setDescription(HashMap<String, Integer> description) {
        this.description = description;
    }

    public int getStudentID() {
        return studentID;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public Date getPaidDate() {
        return paidDate;
    }

    public Time getPaidTime() {
        return paidTime;
    }

    public String getStatus() {
        return status;
    }

    public String getMethod() {
        return method;
    }

    public int getAmount() {
        return amount;
    }

    public int getPaidAmount() {
        return paidAmount;
    }

    public HashMap<String, Integer> getDescription() {
        return description;
    }

    @ColumnInfo(name = "Amount Paid")
    int paidAmount;

    @ColumnInfo(name = "Description")
    HashMap<String, Integer> description;

}
