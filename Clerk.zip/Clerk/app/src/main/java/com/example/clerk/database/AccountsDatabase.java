package com.example.clerk.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {studentTable.class, GroupTable.class, PaymentRecord.class}, version = 1)
public abstract class AccountsDatabase extends RoomDatabase {

    public abstract StudentDAO studentDAO();
    public abstract GroupDAO groupDAO();
    public abstract PaymentRecordDAO paymentRecordDAO();

    private static volatile AccountsDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    static AccountsDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AccountsDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            AccountsDatabase.class, "account_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
